import boto3
import os

ec2 = boto3.client('ec2')
ssm = boto3.client('ssm')

def handler(event, context):
    instance_id = event['detail']['instance-id']
    
    # Describe the instance to get details
    response = ec2.describe_instances(InstanceIds=[instance_id])
    
    if not response.get('Reservations'):
        raise ValueError(f"No reservations found for instance {instance_id}")

    instances = response['Reservations'][0].get('Instances', [])
    if not instances:
        raise ValueError(f"No instances found in reservation for {instance_id}")

    instance_tags = instances[0].get('Tags', [])
    
    # Check if the instance has the Name tag and if it's "jenkins_master"
    instance_name = next((tag['Value'] for tag in instance_tags if tag['Key'] == 'Name'), None)
    
    if instance_name != "jenkins_master":
        print(f"Ignoring instance {instance_id} with Name tag: {instance_name}")
        return {'statusCode': 200, 'body': f"Ignored instance {instance_id} (not jenkins_master)"}
    
    # Find the volume attached to /dev/xvdaf
    block_devices = instances[0].get('BlockDeviceMappings', [])
    volume_id = None

    for device in block_devices:
        if device.get('DeviceName') == "/dev/xvdaf":
            volume_id = device.get('Ebs', {}).get('VolumeId')
            break

    if not volume_id:
        raise ValueError(f"No volume found attached to /dev/xvdaf on instance {instance_id}")

    print(f"Found volume {volume_id} attached to /dev/xvdaf")

    # Get the previous snapshots for the volume tagged as 'jenkins_backup'
    snapshots_response = ec2.describe_snapshots(
        Filters=[
            {'Name': 'volume-id', 'Values': [volume_id]},
            {'Name': 'tag:Name', 'Values': ['jenkins_backup']}
        ]
    )
    
    snapshots = snapshots_response.get('Snapshots', [])
    
    if snapshots:
        snapshots_sorted = sorted(snapshots, key=lambda x: x['StartTime'], reverse=True)
        if len(snapshots_sorted) > 1:
            previous_snapshot = snapshots_sorted[1]
            print(f"Deleting previous snapshot {previous_snapshot['SnapshotId']}")
            ec2.delete_snapshot(SnapshotId=previous_snapshot['SnapshotId'])
    
    # Get snapshot tag from environment variable or default to 'jenkins_backup'
    snapshot_tag = os.environ.get('SNAPSHOT_TAG', 'jenkins_backup')

    # Create a new snapshot
    snapshot = ec2.create_snapshot(
        VolumeId=volume_id,
        Description=f"Snapshot of {volume_id} before instance {instance_id} termination",
        TagSpecifications=[
            {
                'ResourceType': 'snapshot',
                'Tags': [
                    {'Key': 'Name', 'Value': snapshot_tag}
                ]
            }
        ]
    )
    
    snapshot_id = snapshot['SnapshotId']
    print(f"Created snapshot {snapshot_id} for volume {volume_id}")

    # Update SSM Parameter Store with the new snapshot ID
    parameter_name = '/jenkins/latest_snapshot_id'
    ssm.put_parameter(
        Name=parameter_name,
        Value=snapshot_id,
        Type='String',
        Overwrite=True
    )
    
    print(f"Updated SSM Parameter Store with snapshot ID: {snapshot_id}")
    
    return {
        'statusCode': 200,
        'body': f"Snapshot {snapshot_id} created and SSM Parameter Store updated successfully"
    }
